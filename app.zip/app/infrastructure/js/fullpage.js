new fullpage('#fullpage', {
    sectionSelector: '.full-page',
    navigation: true,
    keyboardScrolling: false,
    responsiveHeight: 900,
    responsiveWidth: 1490,
});

//methods
fullpage_api.setAllowScrolling(true);